"""FUBBU Sidecar — main entry point and orchestration loop.

The sidecar runs as an independent OS process alongside VW Nexus.
It polls Nexus for ready tasks, runs the Router-Worker-Verifier loop,
and posts verified results back to Nexus.

This is the ONLY module that coordinates all FUBBU components together.
It owns the lifecycle: registration, polling, task processing, heartbeat,
checkpoint, and graceful shutdown.

Architecture:
  ┌──────────┐     HTTP      ┌─────────────────────────────────────┐
  │  NEXUS   │ ←──────────→  │  FUBBU SIDECAR (this process)       │
  │  :8651   │               │                                     │
  └──────────┘               │  ┌─────────┐  ┌────────┐  ┌────────┐│
                             │  │ Router  │→│ Worker │→│Verifier││
                             │  └────┬────┘  └───┬────┘  └───┬────┘│
                             │       │           │            │     │
                             │  ┌────▼───────────▼────────────▼──┐  │
                             │  │     State / Telemetry / Topo   │  │
                             │  │     (isolated SQLite DBs)      │  │
                             │  └───────────────────────────────┘  │
                             └─────────────────────────────────────┘
"""

from __future__ import annotations

import json
import os
import signal
import sys
import threading
import time
from pathlib import Path
from typing import Any, Dict, Optional

from .fubbu_state import FubbuState
from .fubbu_nexus_client import FubbuNexusClient
from .fubbu_telemetry import FubbuTelemetry, StepType, StepStatus
from .fubbu_topography import FubbuTopography
from .fubbu_router import FubbuRouter
from .fubbu_worker import FubbuWorker
from .fubbu_verifier import FubbuVerifier


def _load_config(config_path: Optional[str] = None) -> Dict[str, Any]:
    """Load FUBBU configuration from YAML."""
    if config_path is None:
        config_path = str(Path(__file__).parent / "fubbu_config.yaml")
    try:
        import yaml
        with open(config_path, "r", encoding="utf-8") as f:
            return yaml.safe_load(f)
    except ImportError:
        # Fallback: minimal defaults
        return _default_config()
    except FileNotFoundError:
        return _default_config()


def _default_config() -> Dict[str, Any]:
    return {
        "schema_version": "1.0",
        "sidecar": {
            "name": "FUBBU",
            "agent_id": "fubbu_router",
            "nexus_url": "http://127.0.0.1:8651",
            "heartbeat_interval_s": 30,
            "poll_interval_s": 5,
            "max_concurrent_tasks": 3,
            "capabilities": ["low_level_debug", "mips_analysis", "binary_diff"],
        },
        "state": {
            "db_path": "tools/fubbu/data/fubbu_state.db",
            "lock_file": "tools/fubbu/data/fubbu.lock",
            "checkpoint_interval_s": 60,
        },
        "models": {
            "router": {"endpoint": "http://127.0.0.1:11434/api/generate",
                       "model": "qwen2.5-coder:7b", "temperature": 0.3,
                       "max_tokens": 2048, "timeout_s": 60, "num_ctx": 8192},
            "worker": {"endpoint": "http://127.0.0.1:11434/api/generate",
                       "model": "deepseek-coder:6.7b", "temperature": 0.1,
                       "max_tokens": 4096, "timeout_s": 180, "num_ctx": 32768},
            "verifier": {"endpoint": "http://127.0.0.1:11434/api/generate",
                         "model": "qwen2.5-coder:7b", "temperature": 0.0,
                         "max_tokens": 1024, "timeout_s": 60, "num_ctx": 8192},
        },
        "loop": {
            "max_iterations": 5, "retry_backoff_base_s": 2,
            "retry_max_attempts": 3, "verifier_confidence_threshold": 0.7,
            "feedback_on_reject": True,
        },
        "telemetry": {
            "log_path": "tools/fubbu/data/fubbu_telemetry.log",
            "metrics_db_path": "tools/fubbu/data/fubbu_metrics.db",
            "step_log_path": "tools/fubbu/data/fubbu_steps.jsonl",
            "mirror_to_nexus": True, "mirror_interval_s": 10,
            "log_level": "INFO",
        },
        "topography": {
            "graph_db_path": "tools/fubbu/data/fubbu_topography.db",
            "export_dot_path": "tools/fubbu/data/fubbu_topology.dot",
            "export_json_path": "tools/fubbu/data/fubbu_topology.json",
            "auto_export": True, "track_token_flow": True,
        },
        "rag": {"enabled": True, "max_chunks": 15, "corpus_filter": None},
    }


class FubbuSidecar:
    """Main FUBBU sidecar process.

    Lifecycle:
      1. Acquire file lock (prevent dual instances)
      2. Initialize all components (state, telemetry, topography, router, worker, verifier)
      3. Register with Nexus as agent
      4. Start heartbeat thread
      5. Poll Nexus for ready tasks
      6. For each task: Router → Worker → Verifier loop (with feedback retries)
      7. Post verified result to Nexus
      8. On shutdown: unregister, release lock, export topology
    """

    def __init__(self, config_path: Optional[str] = None,
                 project_root: Optional[str] = None):
        self.config = _load_config(config_path)
        self.project_root = Path(project_root or os.getcwd())
        self._running = False
        self._stop_event = threading.Event()
        self._lock_fd = None
        self._heartbeat_thread: Optional[threading.Thread] = None
        self._checkpoint_thread: Optional[threading.Thread] = None

        # Resolve paths relative to project root
        state_cfg = self.config.get("state", {})
        tel_cfg = self.config.get("telemetry", {})
        topo_cfg = self.config.get("topography", {})

        def _resolve(p: str) -> str:
            if os.path.isabs(p):
                return p
            return str(self.project_root / p)

        # ── Initialize components ────────────────────────────
        self.state = FubbuState(_resolve(state_cfg.get("db_path", "tools/fubbu/data/fubbu_state.db")))

        self.telemetry = FubbuTelemetry(
            log_path=_resolve(tel_cfg.get("log_path", "tools/fubbu/data/fubbu_telemetry.log")),
            metrics_db_path=_resolve(tel_cfg.get("metrics_db_path", "tools/fubbu/data/fubbu_metrics.db")),
            step_log_path=_resolve(tel_cfg.get("step_log_path", "tools/fubbu/data/fubbu_steps.jsonl")),
            mirror_to_nexus=tel_cfg.get("mirror_to_nexus", True),
            mirror_interval_s=tel_cfg.get("mirror_interval_s", 10),
            log_level=tel_cfg.get("log_level", "INFO"),
        )

        self.topography = FubbuTopography(
            graph_db_path=_resolve(topo_cfg.get("graph_db_path", "tools/fubbu/data/fubbu_topography.db")),
            export_dot_path=_resolve(topo_cfg.get("export_dot_path", "tools/fubbu/data/fubbu_topology.dot")),
            export_json_path=_resolve(topo_cfg.get("export_json_path", "tools/fubbu/data/fubbu_topology.json")),
            auto_export=topo_cfg.get("auto_export", True),
            track_token_flow=topo_cfg.get("track_token_flow", True),
        )

        # ── Nexus client ─────────────────────────────────────
        sc = self.config.get("sidecar", {})
        self.nexus = FubbuNexusClient(
            nexus_url=sc.get("nexus_url", "http://127.0.0.1:8651"),
            agent_id=sc.get("agent_id", "fubbu_router"),
            agent_name=sc.get("name", "FUBBU"),
            capabilities=sc.get("capabilities", ["low_level_debug"]),
        )
        self.telemetry.set_nexus_client(self.nexus)

        # ── Router, Worker, Verifier ─────────────────────────
        models = self.config.get("models", {})
        router_cfg = models.get("router", {})
        worker_cfg = models.get("worker", {})
        verifier_cfg = models.get("verifier", {})

        self.worker = FubbuWorker(
            state=self.state, telemetry=self.telemetry, topography=self.topography,
            model=worker_cfg.get("model", "deepseek-coder:6.7b"),
            endpoint=worker_cfg.get("endpoint", "http://127.0.0.1:11434/api/generate"),
            temperature=worker_cfg.get("temperature", 0.1),
            max_tokens=worker_cfg.get("max_tokens", 4096),
            timeout_s=worker_cfg.get("timeout_s", 180),
            num_ctx=worker_cfg.get("num_ctx", 32768),
            max_retries=self.config.get("loop", {}).get("retry_max_attempts", 3),
            retry_backoff_base_s=self.config.get("loop", {}).get("retry_backoff_base_s", 2.0),
        )

        rag_cfg = self.config.get("rag", {})
        self.router = FubbuRouter(
            nexus_client=self.nexus, worker=self.worker,
            state=self.state, telemetry=self.telemetry, topography=self.topography,
            model=router_cfg.get("model", "qwen2.5-coder:7b"),
            endpoint=router_cfg.get("endpoint", "http://127.0.0.1:11434/api/generate"),
            temperature=router_cfg.get("temperature", 0.3),
            max_tokens=router_cfg.get("max_tokens", 2048),
            timeout_s=router_cfg.get("timeout_s", 60),
            rag_enabled=rag_cfg.get("enabled", True),
            rag_max_chunks=rag_cfg.get("max_chunks", 15),
            rag_corpus=rag_cfg.get("corpus_filter"),
        )

        loop_cfg = self.config.get("loop", {})
        self.verifier = FubbuVerifier(
            state=self.state, telemetry=self.telemetry, topography=self.topography,
            model=verifier_cfg.get("model", "qwen2.5-coder:7b"),
            endpoint=verifier_cfg.get("endpoint", "http://127.0.0.1:11434/api/generate"),
            temperature=verifier_cfg.get("temperature", 0.0),
            max_tokens=verifier_cfg.get("max_tokens", 1024),
            timeout_s=verifier_cfg.get("timeout_s", 60),
            confidence_threshold=loop_cfg.get("verifier_confidence_threshold", 0.7),
        )

        self.max_iterations = loop_cfg.get("max_iterations", 5)
        self.feedback_on_reject = loop_cfg.get("feedback_on_reject", True)
        self.poll_interval = sc.get("poll_interval_s", 5)
        self.heartbeat_interval = sc.get("heartbeat_interval_s", 30)
        self.checkpoint_interval = state_cfg.get("checkpoint_interval_s", 60)

    # ── File Lock ────────────────────────────────────────────

    def _acquire_lock(self) -> bool:
        lock_path = self.project_root / self.config.get("state", {}).get(
            "lock_file", "tools/fubbu/data/fubbu.lock"
        )
        lock_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            import msvcrt
            self._lock_fd = open(lock_path, "w")
            msvcrt.locking(self._lock_fd.fileno(), msvcrt.LK_NBLCK, 1)
            self._lock_fd.write(str(os.getpid()))
            self._lock_fd.flush()
            return True
        except (OSError, ImportError):
            try:
                import fcntl
                self._lock_fd = open(lock_path, "w")
                fcntl.flock(self._lock_fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                self._lock_fd.write(str(os.getpid()))
                self._lock_fd.flush()
                return True
            except (OSError, ImportError):
                # Fallback: check PID file
                if lock_path.exists():
                    try:
                        old_pid = int(lock_path.read_text().strip())
                        if os.path.exists(f"/proc/{old_pid}") or self._is_process_running(old_pid):
                            return False
                    except (ValueError, FileNotFoundError):
                        pass
                lock_path.write_text(str(os.getpid()))
                self._lock_fd = open(lock_path, "r")
                return True

    @staticmethod
    def _is_process_running(pid: int) -> bool:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False

    def _release_lock(self) -> None:
        if self._lock_fd:
            try:
                self._lock_fd.close()
            except Exception:
                pass
            self._lock_fd = None

    # ── Heartbeat ────────────────────────────────────────────

    def _heartbeat_loop(self) -> None:
        while self._running and not self._stop_event.is_set():
            try:
                self.nexus.heartbeat(state="idle" if not self._busy else "working")
                self.telemetry.record_step(
                    StepType.HEARTBEAT, StepStatus.SUCCESS,
                    agent_role="sidecar",
                )
            except Exception:
                pass
            self._stop_event.wait(self.heartbeat_interval)

    # ── Checkpoint ───────────────────────────────────────────

    def _checkpoint_loop(self) -> None:
        while self._running and not self._stop_event.is_set():
            self._stop_event.wait(self.checkpoint_interval)
            if self._stop_event.is_set():
                break
            try:
                self.state.checkpoint()
                self.telemetry.record_step(
                    StepType.CHECKPOINT, StepStatus.SUCCESS,
                    agent_role="sidecar",
                )
            except Exception:
                pass

    # ── Task Processing ──────────────────────────────────────

    _busy = False

    def _process_task(self, nexus_task: Dict[str, Any]) -> None:
        """Run the full Router→Worker→Verifier loop for a single task."""
        task_id = nexus_task.get("task_id", "")
        task_title = nexus_task.get("title", "Untitled")
        task_desc = nexus_task.get("description", "")

        self._busy = True
        self.nexus.heartbeat(state="working", current_task=task_id, current_task_title=task_title)

        try:
            # ── Stage 1: Router ───────────────────────────────
            router_result = self.router.process_task(nexus_task)
            if not router_result.get("ok"):
                self.nexus.fail_task(task_id, f"Router failed: {router_result.get('error', '')}")
                self.telemetry.record_step(
                    StepType.FAIL, StepStatus.FAILED,
                    task_id=router_result.get("fubbu_task_id", ""),
                    metadata={"stage": "router", "error": router_result.get("error")},
                )
                return

            fubbu_task_id = router_result["fubbu_task_id"]
            worker_prompt = router_result["worker_prompt"]
            constraints = router_result["constraints"]
            expected_format = router_result["expected_format"]

            self.state.update_task_status(fubbu_task_id, "working")

            # ── Stage 2+3: Worker → Verifier loop ────────────
            for iteration in range(self.max_iterations):
                # Worker
                worker_result = self.worker.execute(
                    fubbu_task_id=fubbu_task_id,
                    worker_prompt=worker_prompt,
                    constraints=constraints,
                    expected_format=expected_format,
                    iteration_num=iteration,
                )

                if not worker_result.get("ok"):
                    self.nexus.fail_task(task_id, f"Worker failed: {worker_result.get('error', '')}")
                    self.telemetry.record_step(
                        StepType.FAIL, StepStatus.FAILED,
                        task_id=fubbu_task_id,
                        metadata={"stage": "worker", "iteration": iteration,
                                  "error": worker_result.get("error")},
                    )
                    return

                # Verifier
                verify_result = self.verifier.verify(
                    fubbu_task_id=fubbu_task_id,
                    iteration_id=worker_result.get("iteration_id", ""),
                    task_description=task_desc,
                    worker_output=worker_result["output"],
                    parsed_output=worker_result["parsed"],
                    iteration_num=iteration,
                )

                if verify_result.get("passed"):
                    # ── COMPLETE: Post verified result to Nexus ──
                    self.topography.record_complete(
                        fubbu_task_id,
                        tokens_in=verify_result.get("advisory_score", 0),
                    )

                    result_payload = {
                        "fubbu_task_id": fubbu_task_id,
                        "iterations": iteration + 1,
                        "worker_output": worker_result["output"],
                        "verifier_score": verify_result.get("advisory_score", 0),
                        "verifier_assessment": verify_result.get("advisory_output", ""),
                        "model": worker_result.get("model", ""),
                        "tokens": {
                            "in": worker_result.get("tokens_in", 0),
                            "out": worker_result.get("tokens_out", 0),
                        },
                    }

                    self.nexus.complete_task(task_id, result=result_payload)
                    self.state.complete_task(fubbu_task_id)
                    self.telemetry.record_step(
                        StepType.COMPLETE, StepStatus.SUCCESS,
                        task_id=fubbu_task_id, agent_role="sidecar",
                        metadata={"iterations": iteration + 1,
                                  "verifier_score": verify_result.get("advisory_score", 0)},
                    )

                    # Auto-export topology
                    if self.topography.auto_export:
                        self.topography.export_all()

                    return

                # ── FEEDBACK: Verifier rejected ───────────────
                self.telemetry.record_step(
                    StepType.FEEDBACK, StepStatus.STARTED,
                    task_id=fubbu_task_id, agent_role="verifier",
                    metadata={"iteration": iteration,
                              "rejection": verify_result.get("rejection_reason", "")},
                )
                self.topography.record_feedback(
                    fubbu_task_id, iteration_id=f"iter_{iteration}",
                )

                if not self.feedback_on_reject or iteration >= self.max_iterations - 1:
                    # Max iterations reached — fail the task
                    self.nexus.fail_task(
                        task_id,
                        f"FUBBU: Max iterations ({self.max_iterations}) reached. "
                        f"Last rejection: {verify_result.get('rejection_reason', 'unknown')}",
                    )
                    self.telemetry.record_step(
                        StepType.FAIL, StepStatus.FAILED,
                        task_id=fubbu_task_id,
                        metadata={"reason": "max_iterations", "iterations": iteration + 1},
                    )
                    return

                # Re-execute with feedback
                worker_result = self.worker.execute_with_feedback(
                    fubbu_task_id=fubbu_task_id,
                    original_prompt=worker_prompt,
                    rejection_reason=verify_result.get("rejection_reason", ""),
                    constraints=constraints,
                    expected_format=expected_format,
                    iteration_num=iteration + 1,
                )

                if not worker_result.get("ok"):
                    self.nexus.fail_task(task_id, f"Worker feedback retry failed: {worker_result.get('error')}")
                    return

                # Verify the feedback iteration
                verify_result = self.verifier.verify(
                    fubbu_task_id=fubbu_task_id,
                    iteration_id=worker_result.get("iteration_id", ""),
                    task_description=task_desc,
                    worker_output=worker_result["output"],
                    parsed_output=worker_result["parsed"],
                    iteration_num=iteration + 1,
                )

                if verify_result.get("passed"):
                    result_payload = {
                        "fubbu_task_id": fubbu_task_id,
                        "iterations": iteration + 2,
                        "worker_output": worker_result["output"],
                        "verifier_score": verify_result.get("advisory_score", 0),
                        "verifier_assessment": verify_result.get("advisory_output", ""),
                        "model": worker_result.get("model", ""),
                    }
                    self.nexus.complete_task(task_id, result=result_payload)
                    self.state.complete_task(fubbu_task_id)
                    self.telemetry.record_step(
                        StepType.COMPLETE, StepStatus.SUCCESS,
                        task_id=fubbu_task_id, agent_role="sidecar",
                        metadata={"iterations": iteration + 2},
                    )
                    if self.topography.auto_export:
                        self.topography.export_all()
                    return

        except Exception as e:
            self.nexus.fail_task(task_id, f"FUBBU exception: {e}")
            self.telemetry.record_step(
                StepType.FAIL, StepStatus.FAILED,
                agent_role="sidecar",
                metadata={"exception": str(e)},
            )
        finally:
            self._busy = False
            self.nexus.heartbeat(state="idle")

    # ── Main Loop ────────────────────────────────────────────

    def start(self) -> None:
        """Start the FUBBU sidecar."""
        # Acquire lock
        if not self._acquire_lock():
            print("FUBBU: Another instance is already running (lock held). Exiting.", file=sys.stderr)
            return

        print("FUBBU: Sidecar starting...", flush=True)

        # Register with Nexus
        reg = self.nexus.register()
        if not reg.get("ok", False) and not reg.get("agent_id"):
            print(f"FUBBU: Nexus registration failed: {reg.get('error', 'unknown')}", file=sys.stderr)
            print("FUBBU: Continuing in standalone mode (no Nexus connection).", file=sys.stderr)

        self._running = True
        self._stop_event.clear()

        # Start heartbeat thread
        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True)
        self._heartbeat_thread.start()

        # Start checkpoint thread
        self._checkpoint_thread = threading.Thread(target=self._checkpoint_loop, daemon=True)
        self._checkpoint_thread.start()

        # Set up signal handlers for graceful shutdown
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)

        print(f"FUBBU: Registered as '{self.nexus.agent_id}'. Polling Nexus every {self.poll_interval}s.", flush=True)
        print(f"FUBBU: Router model: {self.router.model}", flush=True)
        print(f"FUBBU: Worker model: {self.worker.model}", flush=True)
        print(f"FUBBU: Verifier model: {self.verifier.model}", flush=True)
        print(f"FUBBU: Max iterations per task: {self.max_iterations}", flush=True)
        print(f"FUBBU: Confidence threshold: {self.verifier.confidence_threshold}", flush=True)

        # Main poll loop
        while self._running and not self._stop_event.is_set():
            try:
                if self.nexus.is_nexus_alive():
                    ready = self.nexus.get_ready_tasks()
                    tasks = ready.get("tasks", [])
                    for task in tasks:
                        # Check if task matches our capabilities
                        task_caps = task.get("capabilities", [])
                        if task_caps and not any(c in self.nexus.capabilities for c in task_caps):
                            continue
                        # Claim the task
                        claim = self.nexus.claim_task(task.get("task_id", ""))
                        if claim.get("ok"):
                            print(f"FUBBU: Claimed task {task.get('task_id', '')} — {task.get('title', '')}", flush=True)
                            self._process_task(task)
                else:
                    # Nexus not alive — just wait
                    pass
            except Exception as e:
                print(f"FUBBU: Poll error: {e}", file=sys.stderr)

            self._stop_event.wait(self.poll_interval)

        self._shutdown()

    def _signal_handler(self, signum, frame) -> None:
        print(f"\nFUBBU: Received signal {signum}, shutting down...", flush=True)
        self._running = False
        self._stop_event.set()

    def _shutdown(self) -> None:
        """Graceful shutdown."""
        print("FUBBU: Shutting down...", flush=True)

        # Stop threads
        if self._heartbeat_thread:
            self._heartbeat_thread.join(timeout=5)
        if self._checkpoint_thread:
            self._checkpoint_thread.join(timeout=5)

        # Export topology
        if self.topography.auto_export:
            paths = self.topography.export_all()
            print(f"FUBBU: Topology exported: {paths}", flush=True)

        # Final checkpoint
        try:
            self.state.checkpoint()
        except Exception:
            pass

        # Unregister from Nexus
        try:
            self.nexus.unregister()
        except Exception:
            pass

        # Close DBs
        self.state.close()
        self.telemetry.close()
        self.topography.close()

        # Release lock
        self._release_lock()

        print("FUBBU: Shutdown complete.", flush=True)

    # ── Status ────────────────────────────────────────────────

    def status(self) -> Dict[str, Any]:
        """Get comprehensive FUBBU sidecar status."""
        return {
            "running": self._running,
            "agent_id": self.nexus.agent_id,
            "nexus_alive": self.nexus.is_nexus_alive() if self._running else False,
            "busy": self._busy,
            "models": {
                "router": self.router.model,
                "worker": self.worker.model,
                "verifier": self.verifier.model,
            },
            "state": self.state.status(),
            "telemetry": self.telemetry.status(),
            "topography": self.topography.get_topology_summary(),
            "config": {
                "max_iterations": self.max_iterations,
                "confidence_threshold": self.verifier.confidence_threshold,
                "poll_interval_s": self.poll_interval,
                "heartbeat_interval_s": self.heartbeat_interval,
            },
        }
