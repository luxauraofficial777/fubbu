"""FUBBU Verifier — structural and advisory verification of worker outputs.

The Verifier is the final stage of the Think→Route→Delegate→Execute→Verify
pipeline. It performs two layers of checking:

1. STRUCTURAL (deterministic, no model needed):
   - MIPS address range validation (0x80017F00 - 0x801FFFFF)
   - File existence checks for referenced paths
   - JSON validity for structured outputs
   - Diff applicability for proposed patches
   - Code block syntax for common languages

2. ADVISORY (lightweight model call):
   - "Does this explanation make sense given the task?"
   - "Are there obvious contradictions or hallucinations?"
   - Score 0.0-1.0 confidence

Structural checks are the HARD GATE — if any fail, the output is rejected
regardless of the advisory score. The advisory call is informational only
and feeds into the confidence threshold.
"""

from __future__ import annotations

import json
import os
import re
import time
import urllib.request
import urllib.error
from typing import Any, Dict, List, Optional, Tuple

from .fubbu_telemetry import FubbuTelemetry, StepType, StepStatus
from .fubbu_topography import FubbuTopography
from .fubbu_state import FubbuState


VERIFIER_SYSTEM_PROMPT = """\
You are a FUBBU Verifier agent for the Void Walkers Project.
Your job is to evaluate whether a worker's output is plausible and correct.

You will receive:
- The original task description
- The worker's output
- Any structural check results

Evaluate the output on these criteria:
1. Does it directly address the task?
2. Are technical claims supported by evidence?
3. Are there obvious contradictions or hallucinations?
4. Are proposed fixes technically sound?

Output a JSON object:
{
  "score": 0.0-1.0,
  "assessment": "Brief assessment",
  "issues": ["List of specific issues found"],
  "recommendation": "accept" | "reject" | "revise"
}

Be strict but fair. A score of 0.7+ means acceptable.
"""


# Valid MIPS PSX address range (KUSEG + KSEG0 for PSX)
MIPS_ADDR_MIN = 0x00000000
MIPS_ADDR_MAX = 0x801FFFFF
MIPS_EXE_RANGE_MIN = 0x80017F00
MIPS_EXE_RANGE_MAX = 0x800BCF00


class StructuralChecker:
    """Deterministic structural checks — no model inference required."""

    @staticmethod
    def check_mips_address_range(output: str, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Verify all MIPS addresses are in valid PSX range."""
        addresses = parsed.get("mips_addresses", [])
        if not addresses:
            # Extract from raw output
            addresses = re.findall(r"0x[0-9A-Fa-f]{8}", output)

        invalid = []
        for addr_str in addresses:
            try:
                addr = int(addr_str, 16)
                if addr > MIPS_ADDR_MAX and addr < 0xBFC00000:
                    invalid.append(addr_str)
                elif addr >= 0xBFC00000 and addr <= 0xBFC7FFFF:
                    pass  # BIOS ROM range — valid
            except ValueError:
                invalid.append(addr_str)

        return {
            "check": "mips_address_range",
            "passed": len(invalid) == 0,
            "addresses_found": len(addresses),
            "invalid_addresses": invalid,
        }

    @staticmethod
    def check_file_exists(output: str, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Verify referenced file paths exist on disk."""
        file_paths = parsed.get("file_paths", [])
        if not file_paths:
            file_paths = re.findall(r"[A-Za-z]:\\[^\s\"'<>|]+", output)

        missing = []
        for path in file_paths[:20]:  # Cap at 20 to avoid excessive I/O
            # Strip trailing punctuation
            clean = path.rstrip(".,;:)]}")
            if not os.path.exists(clean):
                missing.append(clean)

        return {
            "check": "file_exists",
            "passed": len(missing) == 0,
            "paths_checked": min(len(file_paths), 20),
            "missing_paths": missing,
        }

    @staticmethod
    def check_json_valid(output: str, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Verify JSON output is valid if expected."""
        if "json" in parsed:
            return {"check": "json_valid", "passed": True}
        if "json_error" in parsed:
            return {
                "check": "json_valid",
                "passed": False,
                "error": parsed["json_error"],
            }
        return {"check": "json_valid", "passed": True, "note": "No JSON expected"}

    @staticmethod
    def check_diff_applicable(output: str, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Check if proposed diffs have valid syntax."""
        diffs = parsed.get("diffs", [])
        if not diffs:
            return {"check": "diff_applicable", "passed": True, "note": "No diffs found"}

        issues = []
        for i, diff in enumerate(diffs):
            lines = diff.strip().split("\n")
            has_hunk = any(line.startswith("@@") for line in lines)
            has_changes = any(
                line.startswith("+") or line.startswith("-")
                for line in lines
                if not line.startswith("+++") and not line.startswith("---")
            )
            if not has_hunk:
                issues.append(f"Diff {i}: Missing @@ hunk header")
            if not has_changes:
                issues.append(f"Diff {i}: No + or - change lines")

        return {
            "check": "diff_applicable",
            "passed": len(issues) == 0,
            "diffs_found": len(diffs),
            "issues": issues,
        }

    @staticmethod
    def check_no_hallucination_markers(output: str, parsed: Dict[str, Any]) -> Dict[str, Any]:
        """Check for common hallucination markers."""
        markers = []
        lower = output.lower()
        # Check for fabricated API names
        if "insufficient_context" in lower:
            markers.append("Worker declared insufficient context — not a failure")
        # Check for impossible address patterns
        impossible = re.findall(r"0x[0-9A-Fa-f]{9,}", output)
        if impossible:
            markers.append(f"Impossible addresses (>32-bit): {impossible[:5]}")
        # Check for placeholder text
        if "lorem ipsum" in lower or "placeholder" in lower:
            markers.append("Contains placeholder text")

        return {
            "check": "no_hallucination_markers",
            "passed": len(markers) == 0,
            "markers": markers,
        }

    @classmethod
    def run_all(cls, output: str, parsed: Dict[str, Any],
                enabled_checks: Optional[List[str]] = None) -> Dict[str, Any]:
        """Run all enabled structural checks."""
        all_checks = {
            "mips_address_range": cls.check_mips_address_range,
            "file_exists": cls.check_file_exists,
            "json_valid": cls.check_json_valid,
            "diff_applicable": cls.check_diff_applicable,
            "no_hallucination_markers": cls.check_no_hallucination_markers,
        }

        enabled = enabled_checks or list(all_checks.keys())
        results = {}
        all_passed = True

        for check_name in enabled:
            if check_name in all_checks:
                result = all_checks[check_name](output, parsed)
                results[check_name] = result
                if not result["passed"]:
                    all_passed = False

        return {
            "all_passed": all_passed,
            "checks": results,
            "failed_count": sum(1 for r in results.values() if not r["passed"]),
            "total_checks": len(results),
        }


class FubbuVerifier:
    """Verifier agent: structural + advisory verification of worker outputs.

    Structural checks are deterministic and act as a hard gate.
    Advisory check uses a small model for semantic plausibility.
    """

    def __init__(
        self,
        state: FubbuState,
        telemetry: FubbuTelemetry,
        topography: FubbuTopography,
        model: str = "qwen2.5-coder:7b",
        endpoint: str = "http://127.0.0.1:11434/api/generate",
        temperature: float = 0.0,
        max_tokens: int = 1024,
        timeout_s: int = 60,
        confidence_threshold: float = 0.7,
        enabled_structural_checks: Optional[List[str]] = None,
    ):
        self.state = state
        self.telemetry = telemetry
        self.topography = topography
        self.model = model
        self.endpoint = endpoint
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.timeout_s = timeout_s
        self.confidence_threshold = confidence_threshold
        self.checker = StructuralChecker()
        self.enabled_checks = enabled_structural_checks or [
            "mips_address_range", "file_exists", "json_valid",
            "diff_applicable", "no_hallucination_markers",
        ]

    def _call_verifier_model(self, prompt: str) -> Dict[str, Any]:
        """Call the small verifier model for advisory assessment."""
        payload = json.dumps({
            "model": self.model,
            "prompt": prompt,
            "system": VERIFIER_SYSTEM_PROMPT,
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "num_predict": self.max_tokens,
            },
        }).encode("utf-8")

        try:
            req = urllib.request.Request(
                self.endpoint, data=payload,
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            start = time.time()
            with urllib.request.urlopen(req, timeout=self.timeout_s) as resp:
                result = json.loads(resp.read().decode("utf-8"))
            latency_ms = (time.time() - start) * 1000
            return {
                "ok": True,
                "output": result.get("response", ""),
                "tokens_in": result.get("prompt_eval_count", 0),
                "tokens_out": result.get("eval_count", 0),
                "latency_ms": latency_ms,
            }
        except Exception as e:
            return {"ok": False, "error": str(e), "output": "",
                    "tokens_in": 0, "tokens_out": 0, "latency_ms": 0}

    def _build_verifier_prompt(
        self,
        task_description: str,
        worker_output: str,
        structural_results: Dict[str, Any],
    ) -> str:
        """Build the prompt for the advisory model check."""
        structural_summary = json.dumps(structural_results, indent=2)
        return (
            f"TASK:\n{task_description}\n\n"
            f"WORKER OUTPUT:\n{worker_output[:4000]}\n\n"
            f"STRUCTURAL CHECK RESULTS:\n{structural_summary}\n\n"
            f"Evaluate the worker's output. Output JSON only."
        )

    def _parse_advisory(self, output: str) -> Dict[str, Any]:
        """Parse the advisory model's JSON output."""
        try:
            start = output.find("{")
            end = output.rfind("}") + 1
            if start >= 0 and end > start:
                return json.loads(output[start:end])
        except (json.JSONDecodeError, ValueError):
            pass
        return {
            "score": 0.5,
            "assessment": "Advisory parsing failed — defaulting to neutral",
            "issues": [],
            "recommendation": "revise",
        }

    def verify(
        self,
        fubbu_task_id: str,
        iteration_id: str,
        task_description: str,
        worker_output: str,
        parsed_output: Dict[str, Any],
        iteration_num: int = 0,
    ) -> Dict[str, Any]:
        """Verify a worker's output.

        Steps:
          1. Run structural checks (hard gate)
          2. If structural passes, run advisory model check
          3. Combine results into final verdict

        Returns dict with verdict, scores, and rejection reason if failed.
        """
        # ── VERIFY: Record start ─────────────────────────────
        self.telemetry.record_step(
            StepType.VERIFY, StepStatus.STARTED,
            task_id=fubbu_task_id, agent_role="verifier",
            model=self.model,
            metadata={"iteration": iteration_num},
        )
        self.topography.record_verify(
            fubbu_task_id, iteration_id=f"iter_{iteration_num}",
            tokens_in=len(worker_output) // 4,
        )

        # ── Layer 1: Structural checks (hard gate) ──────────
        structural = self.checker.run_all(
            worker_output, parsed_output, self.enabled_checks
        )

        if not structural["all_passed"]:
            # Structural failure — reject immediately, skip advisory
            rejection_reasons = []
            for check_name, result in structural["checks"].items():
                if not result["passed"]:
                    rejection_reasons.append(
                        f"{check_name}: {result.get('invalid_addresses', result.get('missing_paths', result.get('issues', result.get('markers', ['failed']))))}"
                    )
            rejection = "; ".join(rejection_reasons)

            self.telemetry.record_step(
                StepType.VERIFY, StepStatus.FAILED,
                task_id=fubbu_task_id, agent_role="verifier",
                metadata={"reason": "structural_failure", "details": structural["checks"]},
            )

            self.state.record_verdict(
                task_id=fubbu_task_id,
                iteration_id=iteration_id,
                structural_results=structural,
                advisory_output="",
                advisory_score=0.0,
                passed=False,
                rejection_reason=rejection,
            )

            return {
                "ok": True,
                "passed": False,
                "verdict": "rejected_structural",
                "rejection_reason": rejection,
                "structural_results": structural,
                "advisory_score": 0.0,
            }

        # ── Layer 2: Advisory model check ───────────────────
        verifier_prompt = self._build_verifier_prompt(
            task_description, worker_output, structural
        )
        advisory_result = self._call_verifier_model(verifier_prompt)

        if advisory_result.get("ok"):
            advisory_parsed = self._parse_advisory(advisory_result["output"])
            advisory_score = float(advisory_parsed.get("score", 0.5))
            advisory_output = advisory_parsed.get("assessment", "")
            recommendation = advisory_parsed.get("recommendation", "revise")
        else:
            advisory_parsed = {"score": 0.5, "assessment": "Advisory model unavailable", "issues": []}
            advisory_score = 0.5
            advisory_output = "Advisory model unavailable — structural checks passed"
            recommendation = "accept"  # Accept on structural pass if advisory unavailable

        tokens_in = advisory_result.get("tokens_in", 0)
        tokens_out = advisory_result.get("tokens_out", 0)
        latency_ms = advisory_result.get("latency_ms", 0)

        # ── Combine into final verdict ──────────────────────
        passed = advisory_score >= self.confidence_threshold and recommendation != "reject"

        verdict = "accepted" if passed else "rejected_advisory"
        rejection_reason = ""
        if not passed:
            issues = advisory_parsed.get("issues", [])
            rejection_reason = f"Advisory score {advisory_score:.2f} < {self.confidence_threshold}. Issues: {'; '.join(issues)}"

        self.telemetry.record_step(
            StepType.VERIFY,
            StepStatus.SUCCESS if passed else StepStatus.FAILED,
            task_id=fubbu_task_id, agent_role="verifier",
            model=self.model,
            tokens_in=tokens_in, tokens_out=tokens_out,
            latency_ms=latency_ms,
            metadata={
                "advisory_score": advisory_score,
                "recommendation": recommendation,
                "structural_passed": True,
            },
        )

        self.state.record_verdict(
            task_id=fubbu_task_id,
            iteration_id=iteration_id,
            structural_results=structural,
            advisory_output=advisory_output,
            advisory_score=advisory_score,
            passed=passed,
            rejection_reason=rejection_reason,
        )

        return {
            "ok": True,
            "passed": passed,
            "verdict": verdict,
            "rejection_reason": rejection_reason,
            "structural_results": structural,
            "advisory_score": advisory_score,
            "advisory_output": advisory_output,
            "recommendation": recommendation,
        }
