"""FUBBU topography mapping layer.

Tracks the agent communication topology across the
Think → Route → Delegate → Execute → Verify → (Feedback | Complete)
pipeline. Builds a directed graph of nodes (agents/roles) and edges
(communication steps) with token flow metadata.

Exports:
  - JSON topology (fubbu_topology.json) — structured graph for UI rendering
  - DOT graph (fubbu_topology.dot) — Graphviz visualization
  - SQLite graph DB (fubbu_topography.db) — queryable topology history
"""

from __future__ import annotations

import enum
import json
import sqlite3
import threading
import time
import uuid
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple


class NodeType(enum.Enum):
    NEXUS = "nexus"          # VW Nexus (task source)
    ROUTER = "router"        # FUBBU Router (task decomposition)
    WORKER = "worker"        # FUBBU Worker (model inference)
    VERIFIER = "verifier"    # FUBBU Verifier (output checking)
    RAG = "rag"              # RAG engine (context retrieval)
    OLLAMA = "ollama"        # Ollama endpoint (model server)
    HUMAN = "human"          # Human operator (optional escalation)


_SCHEMA = """
CREATE TABLE IF NOT EXISTS fubbu_nodes (
    node_id     TEXT PRIMARY KEY,
    node_type   TEXT NOT NULL,
    label       TEXT NOT NULL DEFAULT '',
    model       TEXT NOT NULL DEFAULT '',
    metadata    TEXT NOT NULL DEFAULT '{}',
    first_seen  TEXT NOT NULL,
    last_seen   TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS fubbu_edges (
    edge_id     TEXT PRIMARY KEY,
    source_id   TEXT NOT NULL,
    target_id   TEXT NOT NULL,
    edge_type   TEXT NOT NULL,
    task_id     TEXT NOT NULL DEFAULT '',
    iteration_id TEXT NOT NULL DEFAULT '',
    tokens_transferred INTEGER NOT NULL DEFAULT 0,
    latency_ms  REAL NOT NULL DEFAULT 0.0,
    status      TEXT NOT NULL DEFAULT 'active',
    created     TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_fedges_source ON fubbu_edges(source_id);
CREATE INDEX IF NOT EXISTS idx_fedges_target ON fubbu_edges(target_id);
CREATE INDEX IF NOT EXISTS idx_fedges_task ON fubbu_edges(task_id);

CREATE TABLE IF NOT EXISTS fubbu_topology_snapshots (
    snapshot_id TEXT PRIMARY KEY,
    task_id     TEXT NOT NULL DEFAULT '',
    graph_json  TEXT NOT NULL DEFAULT '{}',
    node_count  INTEGER NOT NULL DEFAULT 0,
    edge_count  INTEGER NOT NULL DEFAULT 0,
    created     TEXT NOT NULL
);
"""


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


class TopologyNode:
    """A node in the FUBBU communication topology."""

    def __init__(self, node_id: str, node_type: NodeType,
                 label: str = "", model: str = "",
                 metadata: Optional[Dict] = None):
        self.node_id = node_id
        self.node_type = node_type
        self.label = label or node_id
        self.model = model
        self.metadata = metadata or {}
        self.first_seen = _now_iso()
        self.last_seen = self.first_seen

    def to_dict(self) -> Dict[str, Any]:
        return {
            "node_id": self.node_id,
            "node_type": self.node_type.value,
            "label": self.label,
            "model": self.model,
            "metadata": self.metadata,
            "first_seen": self.first_seen,
            "last_seen": self.last_seen,
        }


class TopologyEdge:
    """A directed edge representing communication between two nodes."""

    def __init__(self, source_id: str, target_id: str, edge_type: str,
                 task_id: str = "", iteration_id: str = "",
                 tokens_transferred: int = 0, latency_ms: float = 0.0):
        self.edge_id = f"e_{uuid.uuid4().hex[:10]}"
        self.source_id = source_id
        self.target_id = target_id
        self.edge_type = edge_type  # think, route, delegate, execute, verify, feedback, complete
        self.task_id = task_id
        self.iteration_id = iteration_id
        self.tokens_transferred = tokens_transferred
        self.latency_ms = latency_ms
        self.status = "active"
        self.created = _now_iso()

    def to_dict(self) -> Dict[str, Any]:
        return {
            "edge_id": self.edge_id,
            "source_id": self.source_id,
            "target_id": self.target_id,
            "edge_type": self.edge_type,
            "task_id": self.task_id,
            "iteration_id": self.iteration_id,
            "tokens_transferred": self.tokens_transferred,
            "latency_ms": self.latency_ms,
            "status": self.status,
            "created": self.created,
        }


class FubbuTopography:
    """Tracks and exports the FUBBU agent communication topology.

    Builds a directed graph mapping the flow of information across the
    Router-Worker-Verifier pipeline. Every communication step creates an
    edge with token flow and latency metadata.

    Pipeline stages tracked:
      Think    → Nexus to Router (task received)
      Route    → Router to RAG (context query)
      Delegate → Router to Worker (task assigned with context)
      Execute  → Worker to Ollama (inference request)
      Verify   → Worker to Verifier (output submitted)
      Feedback → Verifier to Worker (rejection with constraints)
      Complete → Verifier to Nexus (verified result posted)
    """

    # Standard node IDs for the FUBBU topology
    NEXUS_ID = "nexus"
    ROUTER_ID = "fubbu_router"
    WORKER_ID = "fubbu_worker"
    VERIFIER_ID = "fubbu_verifier"
    RAG_ID = "fubbu_rag"
    OLLAMA_ID = "ollama_local"

    def __init__(
        self,
        graph_db_path: str | Path = "tools/fubbu/data/fubbu_topography.db",
        export_dot_path: str | Path = "tools/fubbu/data/fubbu_topology.dot",
        export_json_path: str | Path = "tools/fubbu/data/fubbu_topology.json",
        auto_export: bool = True,
        track_token_flow: bool = True,
    ):
        self.graph_db_path = Path(graph_db_path)
        self.export_dot_path = Path(export_dot_path)
        self.export_json_path = Path(export_json_path)
        self.auto_export = auto_export
        self.track_token_flow = track_token_flow

        self.graph_db_path.parent.mkdir(parents=True, exist_ok=True)

        self._lock = threading.RLock()
        self._conn: Optional[sqlite3.Connection] = None
        self._nodes: Dict[str, TopologyNode] = {}
        self._edges: List[TopologyEdge] = []
        self._init_db()
        self._init_default_nodes()

    def _init_db(self) -> None:
        with self._lock:
            self._conn = sqlite3.connect(
                str(self.graph_db_path), check_same_thread=False
            )
            self._conn.execute("PRAGMA journal_mode=WAL")
            self._conn.executescript(_SCHEMA)
            self._conn.commit()

    def _init_default_nodes(self) -> None:
        """Initialize the standard FUBBU pipeline nodes."""
        defaults = [
            (self.NEXUS_ID, NodeType.NEXUS, "VW Nexus", ""),
            (self.ROUTER_ID, NodeType.ROUTER, "FUBBU Router", "qwen2.5-coder:7b"),
            (self.WORKER_ID, NodeType.WORKER, "FUBBU Worker", "deepseek-coder:6.7b"),
            (self.VERIFIER_ID, NodeType.VERIFIER, "FUBBU Verifier", "qwen2.5-coder:7b"),
            (self.RAG_ID, NodeType.RAG, "RAG Engine", ""),
            (self.OLLAMA_ID, NodeType.OLLAMA, "Ollama", ""),
        ]
        for node_id, ntype, label, model in defaults:
            self.add_node(node_id, ntype, label=label, model=model)

    # ── Node Management ───────────────────────────────────────

    def add_node(self, node_id: str, node_type: NodeType,
                 label: str = "", model: str = "",
                 metadata: Optional[Dict] = None) -> TopologyNode:
        with self._lock:
            if node_id in self._nodes:
                self._nodes[node_id].last_seen = _now_iso()
                return self._nodes[node_id]
            node = TopologyNode(node_id, node_type, label, model, metadata)
            self._nodes[node_id] = node
            self._conn.execute(
                """INSERT OR REPLACE INTO fubbu_nodes
                   (node_id, node_type, label, model, metadata, first_seen, last_seen)
                   VALUES (?, ?, ?, ?, ?, ?, ?)""",
                (node_id, node_type.value, label, model,
                 json.dumps(metadata or {}), node.first_seen, node.last_seen),
            )
            self._conn.commit()
            return node

    def get_node(self, node_id: str) -> Optional[TopologyNode]:
        with self._lock:
            return self._nodes.get(node_id)

    # ── Edge Management ───────────────────────────────────────

    def add_edge(self, source_id: str, target_id: str, edge_type: str,
                 task_id: str = "", iteration_id: str = "",
                 tokens_transferred: int = 0, latency_ms: float = 0.0) -> TopologyEdge:
        with self._lock:
            edge = TopologyEdge(
                source_id, target_id, edge_type,
                task_id, iteration_id,
                tokens_transferred if self.track_token_flow else 0,
                latency_ms,
            )
            self._edges.append(edge)
            self._conn.execute(
                """INSERT INTO fubbu_edges
                   (edge_id, source_id, target_id, edge_type, task_id,
                    iteration_id, tokens_transferred, latency_ms, status, created)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (edge.edge_id, edge.source_id, edge.target_id, edge.edge_type,
                 edge.task_id, edge.iteration_id, edge.tokens_transferred,
                 edge.latency_ms, edge.status, edge.created),
            )
            self._conn.commit()
            return edge

    # ── Pipeline Step Recording ───────────────────────────────

    def record_think(self, task_id: str, tokens_in: int = 0, latency_ms: float = 0.0):
        """Nexus → Router: task received and analyzed."""
        return self.add_edge(self.NEXUS_ID, self.ROUTER_ID, "think",
                             task_id=task_id, tokens_transferred=tokens_in,
                             latency_ms=latency_ms)

    def record_route(self, task_id: str, tokens_in: int = 0, latency_ms: float = 0.0):
        """Router → RAG: context retrieval query."""
        return self.add_edge(self.ROUTER_ID, self.RAG_ID, "route",
                             task_id=task_id, tokens_transferred=tokens_in,
                             latency_ms=latency_ms)

    def record_delegate(self, task_id: str, iteration_id: str = "",
                        tokens_in: int = 0, latency_ms: float = 0.0):
        """Router → Worker: task assigned with context."""
        return self.add_edge(self.ROUTER_ID, self.WORKER_ID, "delegate",
                             task_id=task_id, iteration_id=iteration_id,
                             tokens_transferred=tokens_in, latency_ms=latency_ms)

    def record_execute(self, task_id: str, iteration_id: str = "",
                       tokens_in: int = 0, tokens_out: int = 0,
                       latency_ms: float = 0.0):
        """Worker → Ollama: inference request → response."""
        edge1 = self.add_edge(self.WORKER_ID, self.OLLAMA_ID, "execute",
                              task_id=task_id, iteration_id=iteration_id,
                              tokens_transferred=tokens_in, latency_ms=latency_ms)
        edge2 = self.add_edge(self.OLLAMA_ID, self.WORKER_ID, "execute_response",
                              task_id=task_id, iteration_id=iteration_id,
                              tokens_transferred=tokens_out, latency_ms=latency_ms)
        return [edge1, edge2]

    def record_verify(self, task_id: str, iteration_id: str = "",
                      tokens_in: int = 0, latency_ms: float = 0.0):
        """Worker → Verifier: output submitted for checking."""
        return self.add_edge(self.WORKER_ID, self.VERIFIER_ID, "verify",
                             task_id=task_id, iteration_id=iteration_id,
                             tokens_transferred=tokens_in, latency_ms=latency_ms)

    def record_feedback(self, task_id: str, iteration_id: str = "",
                        tokens_in: int = 0, latency_ms: float = 0.0):
        """Verifier → Worker: rejection with constraints (feedback loop)."""
        return self.add_edge(self.VERIFIER_ID, self.WORKER_ID, "feedback",
                             task_id=task_id, iteration_id=iteration_id,
                             tokens_transferred=tokens_in, latency_ms=latency_ms)

    def record_complete(self, task_id: str, tokens_in: int = 0,
                        latency_ms: float = 0.0):
        """Verifier → Nexus: verified result posted back."""
        return self.add_edge(self.VERIFIER_ID, self.NEXUS_ID, "complete",
                             task_id=task_id, tokens_transferred=tokens_in,
                             latency_ms=latency_ms)

    # ── Export ────────────────────────────────────────────────

    def export_json(self, path: Optional[str | Path] = None) -> str:
        """Export topology as JSON for UI rendering."""
        export_path = Path(path) if path else self.export_json_path
        with self._lock:
            graph = {
                "nodes": [n.to_dict() for n in self._nodes.values()],
                "edges": [e.to_dict() for e in self._edges],
                "metadata": {
                    "exported_at": _now_iso(),
                    "node_count": len(self._nodes),
                    "edge_count": len(self._edges),
                },
            }
        export_path.parent.mkdir(parents=True, exist_ok=True)
        with open(export_path, "w", encoding="utf-8") as f:
            json.dump(graph, f, indent=2, default=str)

        # Also snapshot to DB
        with self._lock:
            snap_id = f"snap_{uuid.uuid4().hex[:10]}"
            self._conn.execute(
                """INSERT INTO fubbu_topology_snapshots
                   (snapshot_id, task_id, graph_json, node_count, edge_count, created)
                   VALUES (?, '', ?, ?, ?, ?)""",
                (snap_id, json.dumps(graph, default=str),
                 len(graph["nodes"]), len(graph["edges"]), _now_iso()),
            )
            self._conn.commit()

        return str(export_path)

    def export_dot(self, path: Optional[str | Path] = None) -> str:
        """Export topology as Graphviz DOT file for visualization."""
        export_path = Path(path) if path else self.export_dot_path
        with self._lock:
            lines = [
                'digraph FUBBU_Topology {',
                '  rankdir=LR;',
                '  bgcolor="#0d1117";',
                '  node [fontname="Consolas" fontsize=10 style=filled];',
                '  edge [fontname="Consolas" fontsize=8 color="#58a6ff"];',
                '',
            ]

            color_map = {
                NodeType.NEXUS.value: "#1f6feb",
                NodeType.ROUTER.value: "#238636",
                NodeType.WORKER.value: "#8957e5",
                NodeType.VERIFIER.value: "#d29922",
                NodeType.RAG.value: "#1f883d",
                NodeType.OLLAMA.value: "#da3633",
                NodeType.HUMAN.value: "#6e7681",
            }

            for node in self._nodes.values():
                color = color_map.get(node.node_type.value, "#30363d")
                label = f"{node.label}\\n({node.model})" if node.model else node.label
                lines.append(
                    f'  "{node.node_id}" [label="{label}" fillcolor="{color}" '
                    f'fontcolor="white" shape={"box" if node.node_type == NodeType.NEXUS else "ellipse"}];'
                )

            lines.append("")

            # Aggregate edges by source→target→type for cleaner visualization
            edge_agg: Dict[Tuple[str, str, str], Dict] = defaultdict(
                lambda: {"count": 0, "tokens": 0, "latency": 0.0}
            )
            for edge in self._edges:
                key = (edge.source_id, edge.target_id, edge.edge_type)
                edge_agg[key]["count"] += 1
                edge_agg[key]["tokens"] += edge.tokens_transferred
                edge_agg[key]["latency"] += edge.latency_ms

            for (src, tgt, etype), stats in edge_agg.items():
                avg_lat = stats["latency"] / stats["count"] if stats["count"] else 0
                label = f"{etype}\\n×{stats['count']}\\n{stats['tokens']}t\\n{avg_lat:.0f}ms"
                lines.append(f'  "{src}" -> "{tgt}" [label="{label}"];')

            lines.append("}")
            content = "\n".join(lines)

        export_path.parent.mkdir(parents=True, exist_ok=True)
        with open(export_path, "w", encoding="utf-8") as f:
            f.write(content)
        return str(export_path)

    def export_all(self) -> Dict[str, str]:
        """Export topology in all formats."""
        json_path = self.export_json()
        dot_path = self.export_dot()
        return {"json": json_path, "dot": dot_path}

    # ── Querying ──────────────────────────────────────────────

    def get_edges_for_task(self, task_id: str) -> List[Dict[str, Any]]:
        with self._lock:
            rows = self._conn.execute(
                "SELECT * FROM fubbu_edges WHERE task_id = ? ORDER BY created ASC",
                (task_id,),
            ).fetchall()
        return [
            {
                "edge_id": r[0], "source_id": r[1], "target_id": r[2],
                "edge_type": r[3], "task_id": r[4], "iteration_id": r[5],
                "tokens_transferred": r[6], "latency_ms": r[7],
                "status": r[8], "created": r[9],
            }
            for r in rows
        ]

    def get_token_flow_summary(self) -> Dict[str, Any]:
        """Summarize token flow across all edges."""
        with self._lock:
            rows = self._conn.execute(
                "SELECT source_id, target_id, edge_type, "
                "SUM(tokens_transferred) as total_tokens, "
                "COUNT(*) as edge_count, AVG(latency_ms) as avg_lat "
                "FROM fubbu_edges GROUP BY source_id, target_id, edge_type",
            ).fetchall()
        flows = []
        for r in rows:
            flows.append({
                "source": r[0], "target": r[1], "edge_type": r[2],
                "total_tokens": r[3], "edge_count": r[4],
                "avg_latency_ms": round(r[5] or 0, 2),
            })
        return {"flows": flows, "total_edges": len(rows)}

    def get_topology_summary(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "node_count": len(self._nodes),
                "edge_count": len(self._edges),
                "node_types": {
                    ntype: sum(1 for n in self._nodes.values() if n.node_type.value == ntype)
                    for ntype in set(n.node_type.value for n in self._nodes.values())
                },
                "edge_types": dict(
                    self._conn.execute(
                        "SELECT edge_type, COUNT(*) FROM fubbu_edges GROUP BY edge_type"
                    ).fetchall()
                ),
            }

    def close(self) -> None:
        with self._lock:
            if self._conn:
                self._conn.close()
                self._conn = None
