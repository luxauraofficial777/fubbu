# FUBBU — Fully Unmanaged Backbone Bridge Unit

Self-hosted, local multi-agent orchestration sidecar for the Void Walkers Project.

## Overview

FUBBU is a sandboxed Router-Worker-Verifier loop that runs as an independent
OS process alongside VW Nexus. It uses local open-weight models (via Ollama)
for heavy low-level debugging tasks — MIPS analysis, PSX emulator debugging,
binary diffing, architecture review — without risking state corruption of the
core Nexus engine.

## Architecture

```
┌──────────┐     HTTP      ┌─────────────────────────────────────┐
│  NEXUS   │ ←──────────→  │  FUBBU SIDECAR (separate process)   │
│  :8651   │               │                                     │
└──────────┘               │  Think → Route → Delegate → Execute  │
                           │                          → Verify   │
                           │                                     │
                           │  State (fubbu_state.db)             │
                           │  Telemetry (fubbu_metrics.db)       │
                           │  Topography (fubbu_topography.db)   │
                           └─────────────────────────────────────┘
```

### Pipeline Stages

| Stage | Agent | Model | Purpose |
|-------|-------|-------|---------|
| Think | Router | qwen2.5-coder:7b | Analyze task, query RAG for context |
| Route | Router | — | Query Nexus RAG for relevant chunks |
| Delegate | Router → Worker | — | Build structured worker prompt with constraints |
| Execute | Worker | deepseek-coder:6.7b | Run inference on local model via Ollama |
| Verify | Verifier | qwen2.5-coder:7b | Structural checks (hard gate) + advisory score |
| Feedback | Verifier → Worker | — | Re-execute with rejection feedback (if rejected) |
| Complete | Verifier → Nexus | — | Post verified result to Nexus task queue |

### Isolation Guarantees

1. **Process isolation** — FUBBU runs as a subprocess, never imported into Nexus
2. **State containment** — Separate SQLite DBs, never writes to `nexus_state.db`
3. **API-only communication** — All Nexus interaction via HTTP on `:8651`
4. **File lock** — `fubbu.lock` prevents dual instances
5. **Structural verification** — Deterministic checks before model-based advisory

## Quick Start

```powershell
# 1. Ensure Nexus is running
python -m vw_nexus

# 2. Ensure Ollama is running with required models
ollama serve
ollama pull qwen2.5-coder:7b
ollama pull deepseek-coder:6.7b

# 3. Test connectivity
python -m fubbu test-connection

# 4. Start the sidecar
python -m fubbu start

# 5. Check status
python -m fubbu status

# 6. Export topology
python -m fubbu topology --format dot
```

## Configuration

Edit `fubbu_config.yaml` to configure:
- Model endpoints and parameters
- Nexus URL and agent identity
- Telemetry paths and mirroring
- Verifier confidence threshold
- Max iterations per task
- RAG corpus filter

## Module Structure

```
fubbu/
├── __init__.py              # Package exports
├── __main__.py              # CLI entry point (start, status, topology, test-connection)
├── fubbu_config.yaml        # Configuration
├── nexus_router_bridge.py   # Main sidecar entry point + orchestration loop
├── fubbu_router.py          # Router: task decomposition + RAG + worker assignment
├── fubbu_worker.py          # Worker: Ollama/vLLM inference client
├── fubbu_verifier.py        # Verifier: structural checks + advisory model
├── fubbu_state.py           # Isolated SQLite state DB
├── fubbu_nexus_client.py    # Thin HTTP client for Nexus API
├── fubbu_telemetry.py       # Step tracking + state mirroring + metrics
├── fubbu_topography.py      # Agent communication topology map
└── data/                    # Runtime data (DBs, logs, exports)
    ├── fubbu_state.db
    ├── fubbu_metrics.db
    ├── fubbu_topography.db
    ├── fubbu_telemetry.log
    ├── fubbu_steps.jsonl
    ├── fubbu_topology.json
    ├── fubbu_topology.dot
    └── fubbu.lock
```

## Telemetry

Every pipeline step is logged with:
- Step type (think, route, delegate, execute, verify, feedback, complete, fail)
- Step status (started, success, failed, timeout)
- Token counts (input/output)
- Latency (ms)
- Task and iteration IDs
- Model used

Events are optionally mirrored to the Nexus event bus in batches.

## Topography

The topology graph tracks all agent communication with token flow:

```
Nexus → Router → RAG → Router → Worker → Ollama → Worker → Verifier → Nexus
                                                    ↑         ↓
                                                    └─ feedback ┘
```

Exports:
- **JSON** (`fubbu_topology.json`) — for UI rendering
- **DOT** (`fubbu_topology.dot`) — for Graphviz visualization

## Verifier Structural Checks

| Check | Description |
|-------|-------------|
| `mips_address_range` | All MIPS addresses in valid PSX range (0x00000000-0x801FFFFF) |
| `file_exists` | Referenced file paths exist on disk |
| `json_valid` | JSON outputs parse successfully |
| `diff_applicable` | Proposed diffs have valid hunk headers and change lines |
| `no_hallucination_markers` | No impossible addresses, placeholder text, or fabricated APIs |

Structural checks are a **hard gate** — if any fail, the output is rejected
regardless of the advisory model's score.
